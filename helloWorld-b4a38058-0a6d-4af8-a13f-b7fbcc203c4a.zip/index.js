var AWS = require('aws-sdk'); 
var s3 = new AWS.S3();
var bucket='my-pppractice-bucket';
var key='hello.Txt';
var d = new Date(); 
var content = "Hello World on " + d.getDate() + "/"
                + (d.getMonth()+1)  + "/" 
                + d.getFullYear() + " @ "  
                + (d.getHours()+1) + ":"  
                + d.getMinutes() + ":" 
                + d.getSeconds() + " !!";
exports.handler = (event,context,callback) => { 
    const response = {
        statusCode: 200,
        body:content,
    };
    callback(null,response);
    var params = { 'Bucket':bucket,'Key':key,'Body':response.body}; 
    s3.putObject(params, function (err, data) { 
    if (err) 
     console.log(err); 
    else 
     console.log("Successfully saved object to " + bucket + "/" + key); 
});
   console.log("hi------->",params);
};
