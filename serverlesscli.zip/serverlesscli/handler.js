'use strict';

var AWS = require('aws-sdk'); 
var s3 = new AWS.S3();
var bucket='my-pppractice-bucket';

module.exports.helloWorld= (event,context,callback) => {
    var d = new Date(); 
    var date=d.getDate() + "-" + (d.getMonth()+1)  + "-" + d.getFullYear() 
    var time=(d.getHours()+1) + ":" + d.getMinutes() + ":" + d.getSeconds();
    var content = "Hello World on " + date + " @ " + time + " !!";
      /*var content = "Hello World on " + d.getDate() + "/"
                + (d.getMonth()+1)  + "/" 
                + d.getFullYear() + " @ "  
                + (d.getHours()+1) + ":"  
                + d.getMinutes() + ":" 
                + d.getSeconds() + " !!";*/
    var key='Hello'+'_'+date+'_'+time+'.txt';
    const response = {
        statusCode: 200,
        body:content,
    };
    callback(null,response);
    var params = { 'Bucket':bucket,'Key':key,'Body':response.body}; 
    s3.putObject(params, function (err, data) { 
    if (err) 
     console.log(err); 
    else 
     console.log("Successfully saved object to " + bucket + "/" + key); 
});
   console.log("hi------->",params);
};


